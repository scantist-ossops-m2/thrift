typedef bool return
